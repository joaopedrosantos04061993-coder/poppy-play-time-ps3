extern const u8 col_vpo_end[];
extern const u8 col_vpo[];
extern const u32 col_vpo_size;
