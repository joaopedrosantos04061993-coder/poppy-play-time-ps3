extern const u8 tex_fpo_end[];
extern const u8 tex_fpo[];
extern const u32 tex_fpo_size;
