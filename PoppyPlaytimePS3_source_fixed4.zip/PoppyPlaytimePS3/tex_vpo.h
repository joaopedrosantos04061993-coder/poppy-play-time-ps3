extern const u8 tex_vpo_end[];
extern const u8 tex_vpo[];
extern const u32 tex_vpo_size;
