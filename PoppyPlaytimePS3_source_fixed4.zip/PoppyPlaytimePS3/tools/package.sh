#!/usr/bin/env bash
# Monta a árvore app_home/XMB e gera o PKG homebrew para PS3.
set -Eeuo pipefail

export PS3DEV="${PS3DEV:-/opt/ps3dev}"
export PSL1GHT="${PSL1GHT:-$PS3DEV/psl1ght}"
export PATH="$PS3DEV/ppu/bin:$PSL1GHT/bin:$PS3DEV/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
APPID="POPP00001"
CID="UP0001-${APPID}_00-0000000000000000"
TITLE="Poppy Playtime - Capitulo 1"
OUT="$ROOT/dist"
APP="$OUT/app_home"
PKG_OUT="$OUT/PoppyPlaytime_Capitulo1_PS3.pkg"

for command_name in fself sfo pkg; do
  command -v "$command_name" >/dev/null || {
    echo "Ferramenta ausente: $command_name" >&2
    exit 2
  }
done

test -s "$ROOT/poppy_ps3.elf"
for asset in menu_bg.raw chapter_bg.raw font.raw; do
  test -s "$ROOT/assets/$asset" || {
    echo "Asset ausente ou vazio: assets/$asset" >&2
    exit 2
  }
done

test -s "$ROOT/xmb/ICON0.PNG"
test -s "$ROOT/xmb/PIC1.PNG"

rm -rf "$OUT"
mkdir -p "$APP/USRDIR/data"

# EBOOT.BIN: ELF PPU convertido para fake SELF, compatível com CFW/HEN.
echo "[1/4] Gerando EBOOT.BIN"
fself "$ROOT/poppy_ps3.elf" "$APP/USRDIR/EBOOT.BIN"
test -s "$APP/USRDIR/EBOOT.BIN"

# PARAM.SFO: metadados lidos pelo XMB.
echo "[2/4] Gerando PARAM.SFO"
sfo --title "$TITLE" --appid "$APPID" -f "$ROOT/tools/sfo.xml" "$APP/PARAM.SFO"
test -s "$APP/PARAM.SFO"

# Arte e dados do protótipo.
echo "[3/4] Copiando arte e assets"
cp "$ROOT/xmb/ICON0.PNG" "$APP/ICON0.PNG"
cp "$ROOT/xmb/PIC1.PNG" "$APP/PIC1.PNG"
cp "$ROOT/assets/menu_bg.raw" "$APP/USRDIR/data/"
cp "$ROOT/assets/chapter_bg.raw" "$APP/USRDIR/data/"
cp "$ROOT/assets/font.raw" "$APP/USRDIR/data/"

# PKG homebrew/debug.
echo "[4/4] Gerando PKG"
pkg --contentid "$CID" "$APP" "$PKG_OUT"
test -s "$PKG_OUT"

echo "--- tamanhos ---"
stat -c '%s bytes  %n' "$APP/USRDIR/EBOOT.BIN" "$PKG_OUT"
echo "--- conteúdo app_home ---"
find "$APP" -type f -printf '%10s  %p\n' | sort -k2
echo "PKG OK: $PKG_OUT"
