extern const u8 col_fpo_end[];
extern const u8 col_fpo[];
extern const u32 col_fpo_size;
