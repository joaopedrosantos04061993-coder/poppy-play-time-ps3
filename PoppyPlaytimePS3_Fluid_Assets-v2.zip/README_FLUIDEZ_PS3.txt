Pacote otimizado para fluidez no PS3 (PSL1GHT / Tiny3D / RSX) a partir de PoppyPlaytimePS3_FACTORY_ASSETS.zip.

O que foi otimizado para rodar com mais fluidez:
1. Agrupamento por material (batching): os triangulos do Factory_Hub foram ordenados e agrupados por material para reduzir trocas de textura/estado no RSX.
2. Formato binario rapido (factory_portable_opt/Factory_Hub_opt.bin): evita o custo de parsear 22 MB de texto OBJ no Cell/PPU em tempo de execucao.
3. Texturas em potencias de 2 ate 512px (factory_portable_opt/textures/*_512.png): reduz o consumo de VRAM e acelera o upload/amostragem de textura no RSX sem perder legibilidade.
4. Mapa de setores / AABBs (factory_portable_opt/sectors_bounds.json): permite implementar frustum culling e culling por distancia no codigo C.
5. Carregador C para PSL1GHT/Tiny3D (src_opt/factory_fluid_loader.c): base pronta para carregar Factory_Hub_opt.bin e desenhar batches.

Como integrar no seu projeto:
- Copie o conteudo de factory_portable_opt/ para dentro de data/native_assets/ (ou USRDIR/assets/).
- Copie src_opt/factory_fluid_loader.c para src/ e chame pop_factory_load_bin() / pop_factory_render_batches() no seu loop principal.
