# Estado da portagem nativa PSL1GHT

## Pacote atual e teste no console

- A toolchain PPU/SPU, PSL1GHT, bibliotecas auxiliares e Tiny3D estão instalados no sandbox. O Makefile compila e gera PKG NPDRM com `EBOOT.BIN`, `PARAM.SFO`, `ICON0.PNG` e `PIC1.PNG`.
- O usuário confirmou que o pacote aparece no XMB e abre em um PS3 com HEN 4.91, mas a tela fica preta. A revisão `PoppyPlaytimePS3_INSTALL_V2.pkg`, com cores mais claras e sem blending, também ficou preta segundo o usuário. Portanto, a renderização continua com defeito; não gerar outro PKG no chute nem afirmar que está corrigido.
- O `PARAM.SFO` embutido declara `PS3_SYSTEM_VER=01.8000`. Isso é apenas o requisito mínimo declarado; não comprova compatibilidade com HEN 4.89 nem com versões futuras.
- Os pacotes de ~1,1 MB contêm apenas o menu demonstrativo e recursos básicos do XMB. Não contêm o jogo completo de ~70 MB nem gameplay jogável.

## Progresso de assets

- A pasta Unity está disponível em `/home/ubuntu/PoppyPlaytimeUnity`. Ela tem scripts C#, texturas/imagens e os modelos `Factory_Hub.fbx` e `GrabPack_Chapter1.glb`; não contém arquivos `.unity` nem `.prefab` no diretório inspecionado. O código editor `Assets/Editor/BuildPrototypeGame.cs` constrói cenas Unity, então essa lógica precisa ser portada, não compilada pelo PSL1GHT.
- A fábrica FBX foi importada no Blender 4.0.2 e exportada como OBJ triangulado com UVs, normais e MTL: 264 meshes, 251.462 vértices, 187.350 triângulos, 85 materiais; o OBJ ocupa cerca de 22 MB. O original permanece intacto. Ferramenta: `tools/convert_factory_to_obj.py`.
- O GrabPack GLB foi inspecionado: 10 meshes, 55.468 vértices, 85.828 triângulos, 3 armatures e 30 ações. Foi preservado como fonte, pois converter para OBJ descartaria o rig e as animações.
- Os arquivos em `data/native_assets/` ainda não são carregados pelo Tiny3D nem incluídos como conteúdo jogável no PKG.

## Pendências obrigatórias

1. Diagnosticar e corrigir o caminho de renderização que deixa a tela preta, idealmente com saída de depuração mínima e teste no HEN 4.91 do usuário.
2. Implementar carregamento de geometria/materiais no Tiny3D e integrar a fábrica convertida.
3. Definir e implementar um formato runtime para rig/animação do GrabPack (disparos L2/R2) e renderização em primeira pessoa.
4. Portar os scripts C# de movimento, câmera, input PS3, save/checkpoint e fluxo de cenas para C/PSL1GHT.
5. Gerar um único PKG com os recursos realmente integrados e validar no console; sem esse teste, não prometer ausência de tela preta ou compatibilidade geral com HENs futuros.

## Build

Com PS3DEV, PSL1GHT e Tiny3D instalados e as variáveis configuradas:

```sh
make clean
make pkg
```
