/*
 * factory_fluid_loader.c
 * Carregador otimizado para Factory_Hub_opt.bin + texturas POT no PS3 (PSL1GHT / Tiny3D).
 * Agrupa triangulos por material para minimizar trocas de textura/estado no RSX.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <tiny3d.h>

#define POP_BIN_MAGIC "POPTBIN1"

typedef struct __attribute__((packed)) {
    float x, y, z;
    float u, v;
    float nx, ny, nz;
} PopVertex;

typedef struct {
    char mat_name[64];
    char tex_rel[96];
    uint32_t tri_count;
    PopVertex *verts; // tri_count * 3 vertices
    u32 rsx_tex_offset;
    uint32_t tex_w;
    uint32_t tex_h;
    int has_tex;
} PopBatch;

typedef struct {
    uint32_t batch_count;
    uint32_t total_tris;
    PopBatch *batches;
} PopFactoryScene;

int pop_factory_load_bin(const char *path, PopFactoryScene *out_scene) {
    memset(out_scene, 0, sizeof(*out_scene));
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        return -1;
    }

    char magic[8];
    if (fread(magic, 1, 8, fp) != 8 || memcmp(magic, POP_BIN_MAGIC, 8) != 0) {
        fclose(fp);
        return -2;
    }

    uint32_t batch_count = 0, total_tris = 0;
    if (fread(&batch_count, sizeof(uint32_t), 1, fp) != 1 ||
        fread(&total_tris, sizeof(uint32_t), 1, fp) != 1) {
        fclose(fp);
        return -3;
    }

    out_scene->batches = (PopBatch *)calloc(batch_count, sizeof(PopBatch));
    if (!out_scene->batches) {
        fclose(fp);
        return -4;
    }

    out_scene->batch_count = batch_count;
    out_scene->total_tris = total_tris;

    for (uint32_t i = 0; i < batch_count; i++) {
        PopBatch *b = &out_scene->batches[i];
        if (fread(b->mat_name, 1, 64, fp) != 64 ||
            fread(b->tex_rel, 1, 96, fp) != 96 ||
            fread(&b->tri_count, sizeof(uint32_t), 1, fp) != 1) {
            fclose(fp);
            return -5;
        }
        b->mat_name[63] = '\0';
        b->tex_rel[95] = '\0';

        size_t vcount = (size_t)b->tri_count * 3u;
        if (vcount > 0) {
            b->verts = (PopVertex *)malloc(vcount * sizeof(PopVertex));
            if (!b->verts || fread(b->verts, sizeof(PopVertex), vcount, fp) != vcount) {
                fclose(fp);
                return -6;
            }
        }
    }

    fclose(fp);
    return 0;
}

void pop_factory_render_batches(const PopFactoryScene *scene, float max_draw_distance_sq, float cam_x, float cam_y, float cam_z) {
    (void)max_draw_distance_sq;
    (void)cam_x;
    (void)cam_y;
    (void)cam_z;

    if (!scene || !scene->batches) return;

    for (uint32_t i = 0; i < scene->batch_count; i++) {
        const PopBatch *b = &scene->batches[i];
        if (!b->verts || b->tri_count == 0) continue;

        if (b->has_tex && b->rsx_tex_offset != 0) {
            tiny3d_SetTexture(0, b->rsx_tex_offset, b->tex_w, b->tex_h,
                              b->tex_w * 4, TINY3D_TEX_FORMAT_A8R8G8B8, TEXTURE_LINEAR);
        }

        tiny3d_SetPolygon(TINY3D_TRIANGLES);
        uint32_t vcount = b->tri_count * 3u;
        for (uint32_t v = 0; v < vcount; v++) {
            const PopVertex *p = &b->verts[v];
            tiny3d_VertexPos(p->x, p->y, p->z);
            tiny3d_VertexTexture(p->u, p->v);
            tiny3d_Normal(p->nx, p->ny, p->nz);
            tiny3d_VertexColor(0xffffffff);
        }
        tiny3d_End();
    }
}

void pop_factory_free(PopFactoryScene *scene) {
    if (!scene) return;
    if (scene->batches) {
        for (uint32_t i = 0; i < scene->batch_count; i++) {
            free(scene->batches[i].verts);
        }
        free(scene->batches);
        scene->batches = NULL;
    }
    scene->batch_count = 0;
    scene->total_tris = 0;
}
