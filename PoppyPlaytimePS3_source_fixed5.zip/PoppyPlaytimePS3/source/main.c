/*
 * Poppy Playtime - Capitulo 1 (prototipo) - port nativo para PlayStation 3
 *
 * Linguagem: C  |  SDK: PSL1GHT (libRSX / GCM)  |  Nao usa Unity nem C#.
 * Render: pipeline programavel do RSX com dois pares de shaders (textura e cor).
 * Controle: DualShock 3 (analogicos, X, Quadrado, L3, L2/R2, direcional).
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <malloc.h>

#include <ppu-types.h>
#include <ppu-lv2.h>
#include <lv2/process.h>
#include <sysutil/video.h>
#include <io/pad.h>
#include <rsx/rsx.h>
#include <rsx/gcm_sys.h>

#include "tex_vpo.h"
#include "tex_fpo.h"
#include "col_vpo.h"
#include "col_fpo.h"

/* Compatibilidade com versões do bin2o que não expõem os símbolos FPO
 * corretamente no header gerado. Os nomes são os símbolos ELF produzidos
 * a partir de tex.fpo/col.fpo pelos base_rules do PSL1GHT. */
extern const u8 tex_vpo[];
extern const u8 tex_fpo[];
extern const u8 col_vpo[];
extern const u8 col_fpo[];

/* ------------------------------------------------------------------ */
/* configuracao                                                        */
/* ------------------------------------------------------------------ */
#define CB_SIZE        0x100000
#define HOST_SIZE      (4 * 1024 * 1024)
#define MAX_VERTS      20000
#define MAX_WORLD      900
#define GAME_TITLE_ID  "POPP00001"

#define VIRTUAL_W      1280.0f
#define VIRTUAL_H      720.0f

#define FOV_DEG        68.0f
#define NEAR_PLANE     0.08f
#define FAR_PLANE      140.0f

/* ------------------------------------------------------------------ */
/* tipos                                                               */
/* ------------------------------------------------------------------ */
typedef struct { float x, y, z; } vec3;

static vec3 v3(float x, float y, float z) { vec3 r; r.x = x; r.y = y; r.z = z; return r; }
static vec3 vsub(vec3 a, vec3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static float vdot(vec3 a, vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

typedef struct {
    u32 offset;
    u16 w, h;
    u8 *mem;
    int ok;
} texture_t;

typedef struct {
    vec3 p[4];
    float r, g, b;
} wquad;

typedef struct {
    u32 magic;
    u32 version;
    u32 has_save;
    u32 parts;          /* bitmask das 3 pecas */
    float px, py, pz;
    float yaw;
    u32 volume;
    u32 res;            /* 0 = 720p, 1 = 1080p */
    u32 played;
} save_t;

/* ------------------------------------------------------------------ */
/* estado global                                                       */
/* ------------------------------------------------------------------ */
static gcmContextData *g_ctx = NULL;
static u32 g_w = 1280, g_h = 720;
static u32 g_pitch = 0;
static u32 *g_depth = NULL;
static u32 g_depth_off = 0;
static u32 *g_disp[2] = { NULL, NULL };
static u32 g_disp_off[2] = { 0, 0 };
static int g_buf = 0;
static float g_ui = 1.0f;      /* escala da UI (1.0 = 1280x720) */

static texture_t g_tex_menu, g_tex_chapter, g_tex_font;

static rsxVertexProgram *g_vp_tex = NULL;
static rsxVertexProgram *g_vp_col = NULL;
static rsxFragmentProgram *g_fp_tex = NULL;
static rsxFragmentProgram *g_fp_col = NULL;
static void *g_vp_tex_ucode = NULL;
static void *g_vp_col_ucode = NULL;
static u32 g_fp_tex_off = 0;
static u32 g_fp_col_off = 0;

static rsxProgramAttrib *g_at_pos_tex = NULL;
static rsxProgramAttrib *g_at_col_tex = NULL;
static rsxProgramAttrib *g_at_uv_tex = NULL;
static rsxProgramAttrib *g_smp_tex = NULL;
static rsxProgramAttrib *g_at_pos_col = NULL;
static rsxProgramAttrib *g_at_col_col = NULL;

static float *g_vpos = NULL;
static float *g_vcol = NULL;
static float *g_vuv = NULL;
static u32 g_vpos_off = 0, g_vcol_off = 0, g_vuv_off = 0;
static int g_vcount = 0;

static wquad g_world[MAX_WORLD];
static int g_wn = 0;

/* estado do jogo */
typedef enum { ST_MAIN = 0, ST_CHAPTER, ST_OPTIONS, ST_LOADING, ST_GAME, ST_COMPLETE } state_t;
static state_t g_state = ST_MAIN;
static int g_sel = 0;
static int g_opt_sel = 0;
static float g_state_timer = 0.0f;
static char g_msg[160];
static float g_msg_timer = 0.0f;

static save_t g_save;
static char g_save_path[256];

/* jogador */
static vec3 g_pos;
static float g_yaw = 0.0f, g_cam_pitch = 0.0f;
static float g_vy = 0.0f;
static int g_grounded = 1;
static float g_bob = 0.0f;
static int g_parts = 0;
static float g_piece_rot = 0.0f;
static float g_hand_anim[2] = { 0.0f, 0.0f };
static float g_flash = 0.0f;

/* pecas do cenario */
static const vec3 g_piece_pos[3] = {
    { -3.4f, 1.15f, -12.0f },
    {  3.6f, 1.15f, -31.0f },
    {  0.0f, 1.15f, -49.0f }
};
static int g_piece_taken[3] = { 0, 0, 0 };

/* input */
static padData g_pad;
static padData g_pad_prev;

/* ------------------------------------------------------------------ */
/* utilidades de arquivo                                               */
/* ------------------------------------------------------------------ */
static const char *g_bases[] = {
    "",
    "data/",
    "/dev_hdd0/game/" GAME_TITLE_ID "/USRDIR/",
    "/dev_hdd0/game/" GAME_TITLE_ID "/USRDIR/data/",
    "/app_home/USRDIR/",
    "/app_home/USRDIR/data/",
    "/dev_usb000/poppy/",
    NULL
};

static FILE *open_asset(const char *name)
{
    char path[512];
    int i;
    for (i = 0; g_bases[i] != NULL; i++) {
        snprintf(path, sizeof(path), "%s%s", g_bases[i], name);
        FILE *f = fopen(path, "rb");
        if (f) return f;
    }
    return NULL;
}

static void resolve_save_path(void)
{
    static const char *cands[] = {
        "/dev_hdd0/game/" GAME_TITLE_ID "/USRDIR/poppy_save.dat",
        "/dev_hdd0/game/" GAME_TITLE_ID "/poppy_save.dat",
        "/dev_usb000/poppy_save.dat",
        NULL
    };
    int i;
    g_save_path[0] = '\0';
    for (i = 0; cands[i] != NULL; i++) {
        FILE *f = fopen(cands[i], "rb");
        if (f) { fclose(f); snprintf(g_save_path, sizeof(g_save_path), "%s", cands[i]); return; }
    }
    for (i = 0; cands[i] != NULL; i++) {
        FILE *f = fopen(cands[i], "wb");
        if (f) { fclose(f); snprintf(g_save_path, sizeof(g_save_path), "%s", cands[i]); return; }
    }
}

static void save_defaults(void)
{
    memset(&g_save, 0, sizeof(g_save));
    g_save.magic = 0x50504C59; /* PPLY */
    g_save.version = 1;
    g_save.volume = 8;
    g_save.res = 0;
    g_save.px = 0.0f;
    g_save.py = 1.65f;
    g_save.pz = 6.0f;
}

static void save_load(void)
{
    save_defaults();
    resolve_save_path();
    if (g_save_path[0]) {
        FILE *f = fopen(g_save_path, "rb");
        if (f) {
            save_t tmp;
            if (fread(&tmp, 1, sizeof(tmp), f) == sizeof(tmp) && tmp.magic == 0x50504C59) {
                g_save = tmp;
            }
            fclose(f);
        }
    }
}

static void save_write(void)
{
    if (!g_save_path[0]) return;
    FILE *f = fopen(g_save_path, "wb");
    if (!f) return;
    g_save.magic = 0x50504C59;
    g_save.version = 1;
    g_save.parts = (u32)((g_piece_taken[0] ? 1 : 0) | (g_piece_taken[1] ? 2 : 0) | (g_piece_taken[2] ? 4 : 0));
    g_save.px = g_pos.x;
    g_save.py = g_pos.y;
    g_save.pz = g_pos.z;
    g_save.yaw = g_yaw;
    fwrite(&g_save, 1, sizeof(g_save), f);
    fclose(f);
}

/* ------------------------------------------------------------------ */
/* video / RSX                                                         */
/* ------------------------------------------------------------------ */
static void wait_flip(void)
{
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}

static int flip_buffer(int id)
{
    if (gcmSetFlip(g_ctx, id) == 0) {
        rsxFlushBuffer(g_ctx);
        gcmSetWaitFlip(g_ctx);
        return 1;
    }
    return 0;
}

static int init_screen(u32 want_1080)
{
    void *host_addr = NULL;
    videoState state;
    videoConfiguration vconfig;
    videoResolution res;
    u32 i;

    host_addr = memalign(1024 * 1024, HOST_SIZE);
    if (!host_addr) return 0;

    if (rsxInit(&g_ctx, CB_SIZE, HOST_SIZE, host_addr) != 0 || g_ctx == NULL) return 0;

    if (videoGetState(0, 0, &state) != 0) return 0;
    if (videoGetResolution(state.displayMode.resolution, &res) != 0) return 0;

    memset(&vconfig, 0, sizeof(vconfig));
    vconfig.resolution = state.displayMode.resolution;
    if (want_1080) vconfig.resolution = VIDEO_RESOLUTION_1080;
    vconfig.format = VIDEO_BUFFER_FORMAT_XRGB;
    vconfig.pitch = (want_1080 ? 1920u : (u32)res.width) * sizeof(u32);
    vconfig.aspect = state.displayMode.aspect;

    if (videoConfigure(0, &vconfig, NULL, 0) != 0) {
        /* tenta manter a configuracao atual */
        vconfig.resolution = state.displayMode.resolution;
        if (videoConfigure(0, &vconfig, NULL, 0) != 0) return 0;
    }

    if (videoGetState(0, 0, &state) != 0) return 0;
    if (videoGetResolution(state.displayMode.resolution, &res) != 0) return 0;

    g_w = res.width;
    g_h = res.height;
    g_pitch = g_w * sizeof(u32);
    g_ui = (float)g_w / VIRTUAL_W;

    gcmSetFlipMode(GCM_FLIP_VSYNC);

    for (i = 0; i < 2; i++) {
        g_disp[i] = (u32 *)rsxMemalign(64, g_pitch * g_h);
        if (!g_disp[i]) return 0;
        if (rsxAddressToOffset(g_disp[i], &g_disp_off[i]) != 0) return 0;
        if (gcmSetDisplayBuffer(i, g_disp_off[i], g_pitch, (u16)g_w, (u16)g_h) != 0) return 0;
    }

    g_depth = (u32 *)rsxMemalign(64, g_pitch * g_h * 2);
    if (!g_depth) return 0;
    if (rsxAddressToOffset(g_depth, &g_depth_off) != 0) return 0;

    gcmResetFlipStatus();
    return 1;
}

static void set_render_target(int id)
{
    gcmSurface sf;
    memset(&sf, 0, sizeof(sf));
    sf.colorFormat = GCM_SURFACE_X8R8G8B8;
    sf.colorTarget = GCM_SURFACE_TARGET_0;
    sf.colorLocation[0] = GCM_LOCATION_RSX;
    sf.colorOffset[0] = g_disp_off[id];
    sf.colorPitch[0] = g_pitch;
    sf.colorLocation[1] = GCM_LOCATION_RSX;
    sf.colorLocation[2] = GCM_LOCATION_RSX;
    sf.colorLocation[3] = GCM_LOCATION_RSX;
    sf.colorOffset[1] = 0;
    sf.colorOffset[2] = 0;
    sf.colorOffset[3] = 0;
    sf.colorPitch[1] = 64;
    sf.colorPitch[2] = 64;
    sf.colorPitch[3] = 64;
    sf.depthFormat = GCM_SURFACE_ZETA_Z16;
    sf.depthLocation = GCM_LOCATION_RSX;
    sf.depthOffset = g_depth_off;
    sf.depthPitch = g_pitch;
    sf.type = GCM_TEXTURE_LINEAR;
    sf.antiAlias = GCM_SURFACE_CENTER_1;
    sf.width = (u16)g_w;
    sf.height = (u16)g_h;
    sf.x = 0;
    sf.y = 0;
    rsxSetSurface(g_ctx, &sf);
}

static void frame_clear(void)
{
    f32 scale[4], offset[4];
    rsxSetColorMask(g_ctx, GCM_COLOR_MASK_B | GCM_COLOR_MASK_G | GCM_COLOR_MASK_R | GCM_COLOR_MASK_A);
    rsxSetClearColor(g_ctx, 0x00000000);
    rsxClearSurface(g_ctx, GCM_CLEAR_R | GCM_CLEAR_G | GCM_CLEAR_B | GCM_CLEAR_A | GCM_CLEAR_Z);

    scale[0] = (f32)g_w * 0.5f;
    scale[1] = (f32)g_h * -0.5f;
    scale[2] = 0.5f;
    scale[3] = 0.0f;
    offset[0] = (f32)g_w * 0.5f;
    offset[1] = (f32)g_h * 0.5f;
    offset[2] = 0.5f;
    offset[3] = 0.0f;
    rsxSetViewport(g_ctx, 0, 0, (u16)g_w, (u16)g_h, 0.0f, 1.0f, scale, offset);
    rsxSetScissor(g_ctx, 0, 0, (u16)g_w, (u16)g_h);
    rsxSetShadeModel(g_ctx, GCM_SHADE_MODEL_SMOOTH);
    rsxSetCullFaceEnable(g_ctx, GCM_FALSE);
}

/* ------------------------------------------------------------------ */
/* shaders                                                             */
/* ------------------------------------------------------------------ */
static int init_shaders(void)
{
    void *ucode = NULL;
    u32 usize = 0;

    g_vp_tex = (rsxVertexProgram *)tex_vpo;
    g_fp_tex = (rsxFragmentProgram *)tex_fpo;
    g_vp_col = (rsxVertexProgram *)col_vpo;
    g_fp_col = (rsxFragmentProgram *)col_fpo;

    rsxVertexProgramGetUCode(g_vp_tex, &ucode, &usize);
    g_vp_tex_ucode = rsxMemalign(64, usize);
    if (!g_vp_tex_ucode) return 0;
    memcpy(g_vp_tex_ucode, ucode, usize);

    rsxVertexProgramGetUCode(g_vp_col, &ucode, &usize);
    g_vp_col_ucode = rsxMemalign(64, usize);
    if (!g_vp_col_ucode) return 0;
    memcpy(g_vp_col_ucode, ucode, usize);

    rsxFragmentProgramGetUCode(g_fp_tex, &ucode, &usize);
    void *fp_tex_mem = rsxMemalign(64, usize);
    if (!fp_tex_mem) return 0;
    memcpy(fp_tex_mem, ucode, usize);
    rsxAddressToOffset(fp_tex_mem, &g_fp_tex_off);

    rsxFragmentProgramGetUCode(g_fp_col, &ucode, &usize);
    void *fp_col_mem = rsxMemalign(64, usize);
    if (!fp_col_mem) return 0;
    memcpy(fp_col_mem, ucode, usize);
    rsxAddressToOffset(fp_col_mem, &g_fp_col_off);

    g_at_pos_tex = rsxVertexProgramGetAttrib(g_vp_tex, "position");
    g_at_col_tex = rsxVertexProgramGetAttrib(g_vp_tex, "color");
    g_at_uv_tex = rsxVertexProgramGetAttrib(g_vp_tex, "texcoord");
    g_smp_tex = rsxFragmentProgramGetAttrib(g_fp_tex, "texture");

    g_at_pos_col = rsxVertexProgramGetAttrib(g_vp_col, "position");
    g_at_col_col = rsxVertexProgramGetAttrib(g_vp_col, "color");

    if (!g_at_pos_tex || !g_at_col_tex || !g_at_uv_tex || !g_smp_tex) return 0;
    if (!g_at_pos_col || !g_at_col_col) return 0;

    g_vpos = (float *)rsxMemalign(128, MAX_VERTS * 4 * sizeof(float));
    g_vcol = (float *)rsxMemalign(128, MAX_VERTS * 4 * sizeof(float));
    g_vuv = (float *)rsxMemalign(128, MAX_VERTS * 2 * sizeof(float));
    if (!g_vpos || !g_vcol || !g_vuv) return 0;
    rsxAddressToOffset(g_vpos, &g_vpos_off);
    rsxAddressToOffset(g_vcol, &g_vcol_off);
    rsxAddressToOffset(g_vuv, &g_vuv_off);
    return 1;
}

/* ------------------------------------------------------------------ */
/* texturas                                                            */
/* ------------------------------------------------------------------ */
static int load_texture(const char *name, u16 w, u16 h, texture_t *t)
{
    FILE *f;
    u32 size = (u32)w * (u32)h * 4u;
    memset(t, 0, sizeof(*t));
    f = open_asset(name);
    if (!f) {
        printf("asset ausente: %s\n", name);
        return 0;
    }
    t->mem = (u8 *)rsxMemalign(128, size);
    if (!t->mem) { fclose(f); return 0; }
    if (fread(t->mem, 1, size, f) != size) { fclose(f); return 0; }
    fclose(f);
    if (rsxAddressToOffset(t->mem, &t->offset) != 0) return 0;
    t->w = w;
    t->h = h;
    t->ok = 1;
    return 1;
}

static void bind_texture(texture_t *t)
{
    gcmTexture tex;
    u8 unit = (u8)g_smp_tex->index;
    if (!t->ok) return;

    memset(&tex, 0, sizeof(tex));
    tex.format = GCM_TEXTURE_FORMAT_A8R8G8B8 | GCM_TEXTURE_FORMAT_LIN;
    tex.mipmap = 1;
    tex.dimension = GCM_TEXTURE_DIMS_2D;
    tex.cubemap = GCM_FALSE;
    tex.remap = GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_B_SHIFT |
                GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_G_SHIFT |
                GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_R_SHIFT |
                GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_A_SHIFT |
                GCM_TEXTURE_REMAP_COLOR_B << GCM_TEXTURE_REMAP_COLOR_B_SHIFT |
                GCM_TEXTURE_REMAP_COLOR_G << GCM_TEXTURE_REMAP_COLOR_G_SHIFT |
                GCM_TEXTURE_REMAP_COLOR_R << GCM_TEXTURE_REMAP_COLOR_R_SHIFT |
                GCM_TEXTURE_REMAP_COLOR_A << GCM_TEXTURE_REMAP_COLOR_A_SHIFT;
    tex.width = t->w;
    tex.height = t->h;
    tex.depth = 1;
    tex.pitch = (u32)t->w * 4u;
    tex.location = GCM_LOCATION_RSX;
    tex.offset = t->offset;
    rsxLoadTexture(g_ctx, unit, &tex);
    rsxTextureControl(g_ctx, unit, GCM_TRUE, 0 << 8, 12 << 8, GCM_TEXTURE_MAX_ANISO_1);
    rsxTextureFilter(g_ctx, unit, 0, GCM_TEXTURE_LINEAR, GCM_TEXTURE_LINEAR, GCM_TEXTURE_CONVOLUTION_QUINCUNX);
    rsxTextureWrapMode(g_ctx, unit, GCM_TEXTURE_CLAMP_TO_EDGE, GCM_TEXTURE_CLAMP_TO_EDGE,
                       GCM_TEXTURE_CLAMP_TO_EDGE, GCM_TEXTURE_UNSIGNED_REMAP_NORMAL,
                       GCM_TEXTURE_ZFUNC_LESS, 0);
}

/* ------------------------------------------------------------------ */
/* vertices                                                            */
/* ------------------------------------------------------------------ */
static void push_vert(float x, float y, float z, float w,
                      float r, float g, float b, float a,
                      float u, float v)
{
    if (g_vcount >= MAX_VERTS) return;
    g_vpos[g_vcount * 4 + 0] = x;
    g_vpos[g_vcount * 4 + 1] = y;
    g_vpos[g_vcount * 4 + 2] = z;
    g_vpos[g_vcount * 4 + 3] = w;
    g_vcol[g_vcount * 4 + 0] = r;
    g_vcol[g_vcount * 4 + 1] = g;
    g_vcol[g_vcount * 4 + 2] = b;
    g_vcol[g_vcount * 4 + 3] = a;
    g_vuv[g_vcount * 2 + 0] = u;
    g_vuv[g_vcount * 2 + 1] = v;
    g_vcount++;
}

static void draw_range_tex(int start, int count)
{
    if (count <= 0) return;
    rsxLoadVertexProgram(g_ctx, g_vp_tex, g_vp_tex_ucode);
    rsxLoadFragmentProgramLocation(g_ctx, g_fp_tex, g_fp_tex_off, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(g_ctx, (u8)g_at_pos_tex->index, 0, g_vpos_off, sizeof(float) * 4, 4, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(g_ctx, (u8)g_at_col_tex->index, 0, g_vcol_off, sizeof(float) * 4, 4, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(g_ctx, (u8)g_at_uv_tex->index, 0, g_vuv_off, sizeof(float) * 2, 2, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxDrawVertexArray(g_ctx, GCM_TYPE_TRIANGLES, (u32)start, (u32)count);
    rsxInvalidateVertexCache(g_ctx);
}

static void draw_range_col(int start, int count)
{
    if (count <= 0) return;
    rsxLoadVertexProgram(g_ctx, g_vp_col, g_vp_col_ucode);
    rsxLoadFragmentProgramLocation(g_ctx, g_fp_col, g_fp_col_off, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(g_ctx, (u8)g_at_pos_col->index, 0, g_vpos_off, sizeof(float) * 4, 4, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(g_ctx, (u8)g_at_col_col->index, 0, g_vcol_off, sizeof(float) * 4, 4, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxDrawVertexArray(g_ctx, GCM_TYPE_TRIANGLES, (u32)start, (u32)count);
    rsxInvalidateVertexCache(g_ctx);
}

static void set_blend(int on)
{
    if (on) {
        rsxSetBlendEnable(g_ctx, GCM_TRUE);
        rsxSetBlendFunc(g_ctx, GCM_SRC_ALPHA, GCM_ONE_MINUS_SRC_ALPHA, GCM_SRC_ALPHA, GCM_ONE_MINUS_SRC_ALPHA);
        rsxSetBlendEquation(g_ctx, GCM_FUNC_ADD, GCM_FUNC_ADD);
    } else {
        rsxSetBlendEnable(g_ctx, GCM_FALSE);
    }
    rsxSetLogicOpEnable(g_ctx, GCM_FALSE);
}

static void set_depth(int on)
{
    if (on) {
        rsxSetDepthTestEnable(g_ctx, GCM_TRUE);
        rsxSetDepthFunc(g_ctx, GCM_LESS);
    } else {
        rsxSetDepthTestEnable(g_ctx, GCM_FALSE);
    }
}

/* ------------------------------------------------------------------ */
/* primitivas 2D (coordenadas virtuais 1280x720)                       */
/* ------------------------------------------------------------------ */
static float ui_x(float x) { return x * g_ui; }
static float ui_y(float y) { return y * g_ui; }

static void ndc(float px, float py, float *x, float *y)
{
    *x = (px / (float)g_w) * 2.0f - 1.0f;
    *y = 1.0f - (py / (float)g_h) * 2.0f;
}

static void ui_quad(float x, float y, float w, float h,
                    float r, float g, float b, float a)
{
    float x0, y0, x1, y1;
    float sx = ui_x(x), sy = ui_y(y), sw = ui_x(w), sh = ui_y(h);
    ndc(sx, sy, &x0, &y0);
    ndc(sx + sw, sy + sh, &x1, &y1);
    push_vert(x0, y0, 0.0f, 1.0f, r, g, b, a, 0, 0);
    push_vert(x1, y0, 0.0f, 1.0f, r, g, b, a, 1, 0);
    push_vert(x1, y1, 0.0f, 1.0f, r, g, b, a, 1, 1);
    push_vert(x0, y0, 0.0f, 1.0f, r, g, b, a, 0, 0);
    push_vert(x1, y1, 0.0f, 1.0f, r, g, b, a, 1, 1);
    push_vert(x0, y1, 0.0f, 1.0f, r, g, b, a, 0, 1);
}

static void ui_tex_quad(float x, float y, float w, float h,
                        float u0, float v0, float u1, float v1,
                        float r, float g, float b, float a)
{
    float x0, y0, x1, y1;
    float sx = ui_x(x), sy = ui_y(y), sw = ui_x(w), sh = ui_y(h);
    ndc(sx, sy, &x0, &y0);
    ndc(sx + sw, sy + sh, &x1, &y1);
    push_vert(x0, y0, 0.0f, 1.0f, r, g, b, a, u0, v0);
    push_vert(x1, y0, 0.0f, 1.0f, r, g, b, a, u1, v0);
    push_vert(x1, y1, 0.0f, 1.0f, r, g, b, a, u1, v1);
    push_vert(x0, y0, 0.0f, 1.0f, r, g, b, a, u0, v0);
    push_vert(x1, y1, 0.0f, 1.0f, r, g, b, a, u1, v1);
    push_vert(x0, y1, 0.0f, 1.0f, r, g, b, a, u0, v1);
}

static float text_width(const char *s, float scale)
{
    return (float)strlen(s) * 30.0f * scale;
}

/* desenha texto; retorna a largura usada */
static void ui_text(float x, float y, float scale,
                    float r, float g, float b, float a, const char *s)
{
    const float cell = 48.0f;
    const float adv = 30.0f;
    int i;
    float cx = x;
    for (i = 0; s[i] != '\0'; i++) {
        unsigned char c = (unsigned char)s[i];
        int idx, col, row;
        float u0, v0, u1, v1;
        if (c == '\n') { cx = x; y += cell * scale * 0.95f; continue; }
        if (c < 32 || c > 127) c = '?';
        idx = c - 32;
        col = idx % 16;
        row = idx / 16;
        u0 = (col * cell) / 768.0f;
        v0 = (row * cell) / 288.0f;
        u1 = u0 + cell / 768.0f;
        v1 = v0 + cell / 288.0f;
        if (c != ' ')
            ui_tex_quad(cx, y, cell * scale, cell * scale, u0, v0, u1, v1, r, g, b, a);
        cx += adv * scale;
    }
}

static void ui_text_center(float cy, float scale, float r, float g, float b, float a, const char *s)
{
    ui_text((VIRTUAL_W - text_width(s, scale)) * 0.5f, cy, scale, r, g, b, a, s);
}

/* ------------------------------------------------------------------ */
/* cenario 3D                                                          */
/* ------------------------------------------------------------------ */
static void wq(vec3 a, vec3 b, vec3 c, vec3 d, float r, float g, float bl)
{
    if (g_wn >= MAX_WORLD) return;
    g_world[g_wn].p[0] = a;
    g_world[g_wn].p[1] = b;
    g_world[g_wn].p[2] = c;
    g_world[g_wn].p[3] = d;
    g_world[g_wn].r = r;
    g_world[g_wn].g = g;
    g_world[g_wn].b = bl;
    g_wn++;
}

static void wbox(float x0, float y0, float z0, float x1, float y1, float z1,
                 float r, float g, float b)
{
    /* topo */
    wq(v3(x0, y1, z0), v3(x0, y1, z1), v3(x1, y1, z1), v3(x1, y1, z0), r * 1.15f, g * 1.15f, b * 1.15f);
    /* frente (z0) */
    wq(v3(x0, y0, z0), v3(x1, y0, z0), v3(x1, y1, z0), v3(x0, y1, z0), r, g, b);
    /* fundo (z1) */
    wq(v3(x1, y0, z1), v3(x0, y0, z1), v3(x0, y1, z1), v3(x1, y1, z1), r * 0.8f, g * 0.8f, b * 0.8f);
    /* esquerda */
    wq(v3(x0, y0, z1), v3(x0, y0, z0), v3(x0, y1, z0), v3(x0, y1, z1), r * 0.9f, g * 0.9f, b * 0.9f);
    /* direita */
    wq(v3(x1, y0, z0), v3(x1, y0, z1), v3(x1, y1, z1), v3(x1, y1, z0), r * 0.7f, g * 0.7f, b * 0.7f);
}

static void build_level(void)
{
    const float HW = 6.0f;
    const float HH = 4.2f;
    const float Z0 = 9.0f;
    const float Z1 = -66.0f;
    float z;
    int i;

    g_wn = 0;

    for (z = Z0; z > Z1 + 0.01f; z -= 4.0f) {
        float zn = z - 4.0f;
        if (zn < Z1) zn = Z1;
        /* piso */
        wq(v3(-HW, 0.0f, z), v3(HW, 0.0f, z), v3(HW, 0.0f, zn), v3(-HW, 0.0f, zn),
           0.24f, 0.23f, 0.21f);
        /* teto */
        wq(v3(-HW, HH, zn), v3(HW, HH, zn), v3(HW, HH, z), v3(-HW, HH, z),
           0.11f, 0.11f, 0.12f);
        /* parede esquerda */
        wq(v3(-HW, 0.0f, z), v3(-HW, 0.0f, zn), v3(-HW, HH, zn), v3(-HW, HH, z),
           0.31f, 0.30f, 0.28f);
        /* parede direita */
        wq(v3(HW, 0.0f, zn), v3(HW, 0.0f, z), v3(HW, HH, z), v3(HW, HH, zn),
           0.29f, 0.28f, 0.26f);
    }

    /* pilares */
    for (z = 5.0f; z > -62.0f; z -= 8.0f) {
        wbox(-HW, 0.0f, z - 0.35f, -HW + 0.5f, HH, z + 0.35f, 0.36f, 0.34f, 0.31f);
        wbox(HW - 0.5f, 0.0f, z - 0.35f, HW, HH, z + 0.35f, 0.36f, 0.34f, 0.31f);
        /* faixa de aviso */
        wbox(-HW, 1.1f, z - 0.4f, -HW + 0.52f, 1.35f, z + 0.4f, 0.72f, 0.55f, 0.10f);
        wbox(HW - 0.52f, 1.1f, z - 0.4f, HW, 1.35f, z + 0.4f, 0.72f, 0.55f, 0.10f);
    }

    /* esteiras */
    for (i = 0; i < 5; i++) {
        float zz = -6.0f - (float)i * 11.0f;
        wbox(-1.4f, 0.0f, zz - 3.2f, 1.4f, 0.55f, zz + 3.2f, 0.20f, 0.20f, 0.22f);
        wbox(-1.4f, 0.55f, zz - 3.2f, 1.4f, 0.62f, zz + 3.2f, 0.28f, 0.28f, 0.30f);
    }

    /* caixas */
    wbox(-5.0f, 0.0f, -2.0f, -3.6f, 1.2f, -0.6f, 0.42f, 0.33f, 0.20f);
    wbox(-5.2f, 1.2f, -1.8f, -4.2f, 2.1f, -0.8f, 0.46f, 0.36f, 0.22f);
    wbox(3.4f, 0.0f, -8.0f, 4.9f, 1.4f, -6.5f, 0.40f, 0.31f, 0.19f);
    wbox(3.6f, 0.0f, -22.0f, 5.2f, 2.4f, -20.4f, 0.38f, 0.30f, 0.18f);
    wbox(-5.2f, 0.0f, -26.0f, -3.4f, 1.1f, -24.4f, 0.44f, 0.34f, 0.20f);
    wbox(-2.0f, 0.0f, -40.0f, -0.2f, 1.6f, -38.4f, 0.41f, 0.32f, 0.19f);
    wbox(2.2f, 0.0f, -44.0f, 4.0f, 2.0f, -42.2f, 0.39f, 0.31f, 0.18f);

    /* maquinas */
    wbox(-5.9f, 0.0f, -34.0f, -4.2f, 3.4f, -31.6f, 0.26f, 0.27f, 0.30f);
    wbox(4.2f, 0.0f, -34.0f, 5.9f, 3.4f, -31.6f, 0.26f, 0.27f, 0.30f);
    wbox(-5.9f, 3.4f, -34.0f, -4.2f, 3.7f, -31.6f, 0.55f, 0.15f, 0.13f);
    wbox(4.2f, 3.4f, -34.0f, 5.9f, 3.7f, -31.6f, 0.55f, 0.15f, 0.13f);

    /* porta final */
    wbox(-2.2f, 0.0f, -66.0f, 2.2f, 3.6f, -65.6f, 0.20f, 0.19f, 0.18f);
    wbox(-2.6f, 0.0f, -66.0f, -2.2f, 3.9f, -65.4f, 0.45f, 0.42f, 0.38f);
    wbox(2.2f, 0.0f, -66.0f, 2.6f, 3.9f, -65.4f, 0.45f, 0.42f, 0.38f);
    wbox(-2.6f, 3.6f, -66.0f, 2.6f, 3.9f, -65.4f, 0.45f, 0.42f, 0.38f);
}

/* ------------------------------------------------------------------ */
/* camera / projecao                                                   */
/* ------------------------------------------------------------------ */
typedef struct {
    vec3 right, up, fwd;
    vec3 pos;
} camera_t;

static camera_t make_camera(void)
{
    camera_t c;
    float cy = cosf(g_yaw), sy = sinf(g_yaw);
    float cp = cosf(g_cam_pitch), sp = sinf(g_cam_pitch);
    c.pos = g_pos;
    c.fwd = v3(sy * cp, sp, -cy * cp);
    c.right = v3(cy, 0.0f, sy);
    c.up = v3(-sp * sy, cp, sp * cy);
    return c;
}

static void view_space(const camera_t *c, vec3 p, float *vx, float *vy, float *vz)
{
    vec3 d = vsub(p, c->pos);
    *vx = vdot(d, c->right);
    *vy = vdot(d, c->up);
    *vz = -vdot(d, c->fwd);
}

static void project(float vx, float vy, float vz, float *cx, float *cy, float *cz, float *cw)
{
    float f = 1.0f / tanf((FOV_DEG * 0.5f) * 3.14159265f / 180.0f);
    float aspect = (float)g_w / (float)g_h;
    *cw = -vz;
    *cx = (f / aspect) * vx;
    *cy = f * vy;
    *cz = ((FAR_PLANE + NEAR_PLANE) / (NEAR_PLANE - FAR_PLANE)) * vz +
          (2.0f * FAR_PLANE * NEAR_PLANE / (NEAR_PLANE - FAR_PLANE));
}

static float fog_factor(float w)
{
    float d = w;
    float t = (d - 10.0f) / 55.0f;
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    return 1.0f - t * 0.85f;
}

/* triangulo em espaco de mundo, com recorte no near plane */
static void emit_tri(const camera_t *cam, vec3 a, vec3 b, vec3 c,
                     float r, float g, float bl)
{
    vec3 pts[4];
    float vx[4], vy[4], vz[4];
    int n = 0, i;
    vec3 tri[3];
    float t;

    tri[0] = a; tri[1] = b; tri[2] = c;
    for (i = 0; i < 3; i++) view_space(cam, tri[i], &vx[i], &vy[i], &vz[i]);

    /* recorte contra vz <= -NEAR */
    {
        float px[6], py[6], pz[6];
        int m = 0;
        for (i = 0; i < 3; i++) {
            int j = (i + 1) % 3;
            float di = vz[i] + NEAR_PLANE;   /* > 0 = na frente */
            float dj = vz[j] + NEAR_PLANE;
            if (di > 0.0f && m < 6) {
                px[m] = vx[i]; py[m] = vy[i]; pz[m] = vz[i]; m++;
            }
            if ((di > 0.0f) != (dj > 0.0f) && m < 6) {
                t = di / (di - dj);
                px[m] = vx[i] + (vx[j] - vx[i]) * t;
                py[m] = vy[i] + (vy[j] - vy[i]) * t;
                pz[m] = vz[i] + (vz[j] - vz[i]) * t;
                m++;
            }
        }
        n = (m > 4) ? 4 : m;
        for (i = 0; i < n; i++) { vx[i] = px[i]; vy[i] = py[i]; vz[i] = pz[i]; }
    }

    if (n < 3) return;
    for (i = 0; i < n; i++) {
        float cx, cy, cz, cw;
        project(vx[i], vy[i], vz[i], &cx, &cy, &cz, &cw);
        pts[i] = v3(cx, cy, cz);
    }

    {
        float w = -vz[0];
        float ff = fog_factor(w);
        float fr = r * ff + 0.05f * (1.0f - ff);
        float fg = g * ff + 0.05f * (1.0f - ff);
        float fb = bl * ff + 0.06f * (1.0f - ff);
        for (i = 1; i + 1 < n; i++) {
            push_vert(pts[0].x, pts[0].y, pts[0].z, -vz[0], fr, fg, fb, 1.0f, 0, 0);
            push_vert(pts[i].x, pts[i].y, pts[i].z, -vz[i], fr, fg, fb, 1.0f, 0, 0);
            push_vert(pts[i + 1].x, pts[i + 1].y, pts[i + 1].z, -vz[i + 1], fr, fg, fb, 1.0f, 0, 0);
        }
    }
}

static void draw_world_quads(const camera_t *cam)
{
    int i;
    for (i = 0; i < g_wn; i++) {
        wquad *q = &g_world[i];
        emit_tri(cam, q->p[0], q->p[1], q->p[2], q->r, q->g, q->b);
        emit_tri(cam, q->p[0], q->p[2], q->p[3], q->r, q->g, q->b);
    }
}

static void draw_spinning_box(const camera_t *cam, vec3 center, float size, float ang,
                              float r, float g, float b)
{
    vec3 axis[8];
    float ca = cosf(ang), sa = sinf(ang);
    int i;
    for (i = 0; i < 8; i++) {
        float x = (i & 1) ? size : -size;
        float y = (i & 2) ? size : -size;
        float z = (i & 4) ? size : -size;
        float rx = x * ca - z * sa;
        float rz = x * sa + z * ca;
        axis[i] = v3(center.x + rx, center.y + y, center.z + rz);
    }
    /* faces */
    emit_tri(cam, axis[0], axis[1], axis[3], r, g, b);
    emit_tri(cam, axis[0], axis[3], axis[2], r, g, b);
    emit_tri(cam, axis[4], axis[6], axis[7], r * 0.8f, g * 0.8f, b * 0.8f);
    emit_tri(cam, axis[4], axis[7], axis[5], r * 0.8f, g * 0.8f, b * 0.8f);
    emit_tri(cam, axis[0], axis[4], axis[5], r * 0.9f, g * 0.9f, b * 0.9f);
    emit_tri(cam, axis[0], axis[5], axis[1], r * 0.9f, g * 0.9f, b * 0.9f);
    emit_tri(cam, axis[2], axis[3], axis[7], r * 0.7f, g * 0.7f, b * 0.7f);
    emit_tri(cam, axis[2], axis[7], axis[6], r * 0.7f, g * 0.7f, b * 0.7f);
    emit_tri(cam, axis[0], axis[2], axis[6], r, g, b);
    emit_tri(cam, axis[0], axis[6], axis[4], r, g, b);
    emit_tri(cam, axis[1], axis[5], axis[7], r, g, b);
    emit_tri(cam, axis[1], axis[7], axis[3], r, g, b);
}

/* ------------------------------------------------------------------ */
/* colisao simples                                                     */
/* ------------------------------------------------------------------ */
typedef struct { float x0, z0, x1, z1; } box2;

static const box2 g_colliders[] = {
    { -5.0f, -2.0f, -3.6f, -0.6f },
    { -5.2f, -1.8f, -4.2f, -0.8f },
    {  3.4f, -8.0f,  4.9f, -6.5f },
    {  3.6f, -22.0f, 5.2f, -20.4f },
    { -5.2f, -26.0f, -3.4f, -24.4f },
    { -2.0f, -40.0f, -0.2f, -38.4f },
    {  2.2f, -44.0f,  4.0f, -42.2f },
    { -5.9f, -34.0f, -4.2f, -31.6f },
    {  4.2f, -34.0f,  5.9f, -31.6f },
    { -1.4f, -9.2f,   1.4f, -2.8f },
    { -1.4f, -20.2f,  1.4f, -13.8f },
    { -1.4f, -31.2f,  1.4f, -24.8f },
    { -1.4f, -42.2f,  1.4f, -35.8f },
    { -1.4f, -53.2f,  1.4f, -46.8f }
};
#define N_COLLIDERS ((int)(sizeof(g_colliders) / sizeof(g_colliders[0])))

static int blocked(float x, float z)
{
    int i;
    const float rad = 0.42f;
    if (x < -5.5f || x > 5.5f) return 1;
    if (z > 8.4f || z < -65.2f) return 1;
    for (i = 0; i < N_COLLIDERS; i++) {
        if (x > g_colliders[i].x0 - rad && x < g_colliders[i].x1 + rad &&
            z > g_colliders[i].z0 - rad && z < g_colliders[i].z1 + rad)
            return 1;
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* entrada                                                             */
/* ------------------------------------------------------------------ */
static int btn_cross(void)    { return g_pad.BTN_CROSS && !g_pad_prev.BTN_CROSS; }
static int btn_circle(void)   { return g_pad.BTN_CIRCLE && !g_pad_prev.BTN_CIRCLE; }
static int btn_square(void)   { return g_pad.BTN_SQUARE && !g_pad_prev.BTN_SQUARE; }
static int btn_up(void)       { return g_pad.BTN_UP && !g_pad_prev.BTN_UP; }
static int btn_down(void)     { return g_pad.BTN_DOWN && !g_pad_prev.BTN_DOWN; }
static int btn_left(void)     { return g_pad.BTN_LEFT && !g_pad_prev.BTN_LEFT; }
static int btn_right(void)    { return g_pad.BTN_RIGHT && !g_pad_prev.BTN_RIGHT; }
static int btn_start(void)    { return g_pad.BTN_START && !g_pad_prev.BTN_START; }
static int btn_l2(void)       { return g_pad.BTN_L2 && !g_pad_prev.BTN_L2; }
static int btn_r2(void)       { return g_pad.BTN_R2 && !g_pad_prev.BTN_R2; }

static float axis_lx(void) { float v = ((float)g_pad.ANA_L_H - 128.0f) / 127.0f; return clampf(v, -1.0f, 1.0f); }
static float axis_ly(void) { float v = ((float)g_pad.ANA_L_V - 128.0f) / 127.0f; return clampf(v, -1.0f, 1.0f); }
static float axis_rx(void) { float v = ((float)g_pad.ANA_R_H - 128.0f) / 127.0f; return clampf(v, -1.0f, 1.0f); }
static float axis_ry(void) { float v = ((float)g_pad.ANA_R_V - 128.0f) / 127.0f; return clampf(v, -1.0f, 1.0f); }

/* ------------------------------------------------------------------ */
/* logica do jogo                                                      */
/* ------------------------------------------------------------------ */
static void show_msg(const char *m)
{
    snprintf(g_msg, sizeof(g_msg), "%s", m);
    g_msg_timer = 3.0f;
}

static void reset_player(void)
{
    g_pos = v3(0.0f, 1.65f, 6.0f);
    g_yaw = 0.0f;
    g_cam_pitch = 0.0f;
    g_vy = 0.0f;
    g_grounded = 1;
}

static void start_new_chapter(void)
{
    g_piece_taken[0] = g_piece_taken[1] = g_piece_taken[2] = 0;
    g_parts = 0;
    reset_player();
    g_save.has_save = 1;
    g_save.played = 1;
    save_write();
    g_state = ST_LOADING;
    g_state_timer = 0.55f;
    g_sel = 0;
}

static void continue_chapter(void)
{
    int i;
    g_parts = 0;
    for (i = 0; i < 3; i++) {
        g_piece_taken[i] = (g_save.parts >> i) & 1u;
        if (g_piece_taken[i]) g_parts++;
    }
    g_pos = v3(g_save.px, g_save.py, g_save.pz);
    g_yaw = g_save.yaw;
    g_cam_pitch = 0.0f;
    g_vy = 0.0f;
    g_grounded = 1;
    g_state = ST_LOADING;
    g_state_timer = 0.55f;
}

static void try_collect(int via_grab)
{
    int i;
    for (i = 0; i < 3; i++) {
        float dx, dz, dist;
        if (g_piece_taken[i]) continue;
        dx = g_piece_pos[i].x - g_pos.x;
        dz = g_piece_pos[i].z - g_pos.z;
        dist = sqrtf(dx * dx + dz * dz);
        if (dist < (via_grab ? 11.0f : 2.6f)) {
            /* para o grabpack exige olhar na direcao da peca */
            if (via_grab) {
                float ang = atan2f(dx, -dz);
                float diff = ang - g_yaw;
                while (diff > 3.14159f) diff -= 6.28318f;
                while (diff < -3.14159f) diff += 6.28318f;
                if (fabsf(diff) > 0.55f) continue;
            }
            g_piece_taken[i] = 1;
            g_parts++;
            show_msg(via_grab ? "GRABPACK: PECA RECUPERADA" : "PECA RECUPERADA");
            save_write();
            return;
        }
    }
    if (via_grab) show_msg("GRABPACK: NADA AO ALCANCE");
}

static void update_game(float dt)
{
    float mx = 0.0f, mz = 0.0f;
    float speed = 4.6f;
    float look_speed = 2.1f;
    float cy, sy;
    int i;

    /* olhar */
    g_yaw += axis_rx() * look_speed * dt;
    g_cam_pitch += -axis_ry() * look_speed * dt;
    g_cam_pitch = clampf(g_cam_pitch, -1.15f, 1.15f);

    /* correr */
    if (g_pad.BTN_L3) speed = 7.4f;

    /* mover */
    mz = -axis_ly();
    mx = axis_lx();
    if (g_pad.BTN_UP) mz = 1.0f;
    if (g_pad.BTN_DOWN) mz = -1.0f;
    if (g_pad.BTN_LEFT) mx = -1.0f;
    if (g_pad.BTN_RIGHT) mx = 1.0f;

    cy = cosf(g_yaw);
    sy = sinf(g_yaw);

    if (fabsf(mx) > 0.08f || fabsf(mz) > 0.08f) {
        float len = sqrtf(mx * mx + mz * mz);
        float dx, dz;
        if (len > 1.0f) { mx /= len; mz /= len; }
        /* frente = (sy, -cy) ; direita = (cy, sy) */
        dx = (sy * mz + cy * mx) * speed * dt;
        dz = (-cy * mz + sy * mx) * speed * dt;
        if (!blocked(g_pos.x + dx, g_pos.z)) g_pos.x += dx;
        if (!blocked(g_pos.x, g_pos.z + dz)) g_pos.z += dz;
        g_bob += dt * (speed > 5.0f ? 11.0f : 7.5f);
    } else {
        g_bob += dt * 1.2f;
    }

    /* pular */
    if (btn_cross() && g_grounded) {
        g_vy = 4.3f;
        g_grounded = 0;
    }
    if (!g_grounded) {
        g_vy -= 13.0f * dt;
        g_pos.y += g_vy * dt;
        if (g_pos.y <= 1.65f) {
            g_pos.y = 1.65f;
            g_vy = 0.0f;
            g_grounded = 1;
        }
    }

    /* interagir */
    if (btn_square()) try_collect(0);
    if (btn_l2()) { g_hand_anim[0] = 1.0f; try_collect(1); }
    if (btn_r2()) { g_hand_anim[1] = 1.0f; try_collect(1); }
    for (i = 0; i < 2; i++) {
        if (g_hand_anim[i] > 0.0f) {
            g_hand_anim[i] -= dt * 2.4f;
            if (g_hand_anim[i] < 0.0f) g_hand_anim[i] = 0.0f;
        }
    }

    g_piece_rot += dt * 1.4f;

    /* chegou na porta */
    if (g_pos.z < -63.4f) {
        if (g_parts >= 3) {
            g_state = ST_COMPLETE;
            g_save.parts = 7;
            save_write();
        } else if (g_msg_timer <= 0.0f) {
            show_msg("A SAIDA ESTA TRAVADA. FALTAM PECAS.");
            g_pos.z = -63.4f;
        }
    }

    if (btn_start()) {
        save_write();
        g_state = ST_MAIN;
        g_sel = 0;
    }
}

/* ------------------------------------------------------------------ */
/* desenho de telas                                                    */
/* ------------------------------------------------------------------ */
static void draw_background(texture_t *t, float dim)
{
    int start = g_vcount;
    if (t->ok) {
        bind_texture(t);
        ui_tex_quad(0, 0, VIRTUAL_W, VIRTUAL_H, 0, 0, 1, 1, 1, 1, 1, 1);
        draw_range_tex(start, g_vcount - start);
    } else {
        set_blend(0);
        ui_quad(0, 0, VIRTUAL_W, VIRTUAL_H, 0.06f, 0.05f, 0.06f, 1.0f);
        draw_range_col(start, g_vcount - start);
    }
    if (dim > 0.0f) {
        set_blend(1);
        start = g_vcount;
        ui_quad(0, 0, VIRTUAL_W, VIRTUAL_H, 0, 0, 0, dim);
        draw_range_col(start, g_vcount - start);
    }
}

static void draw_text_block(float x, float y, float scale, float r, float g, float b,
                            const char *s)
{
    int start = g_vcount;
    if (!g_tex_font.ok) return;
    bind_texture(&g_tex_font);
    set_blend(1);
    set_depth(0);
    ui_text(x, y, scale, r, g, b, 1.0f, s);
    draw_range_tex(start, g_vcount - start);
}

static void draw_text_centered(float y, float scale, float r, float g, float b, const char *s)
{
    draw_text_block((VIRTUAL_W - text_width(s, scale)) * 0.5f, y, scale, r, g, b, s);
}

static void draw_menu_item(float y, const char *label, int selected)
{
    if (selected) {
        int start = g_vcount;
        set_blend(1);
        set_depth(0);
        ui_quad(96, y - 8, 620, 62, 0.78f, 0.10f, 0.12f, 0.72f);
        ui_quad(96, y - 8, 8, 62, 0.95f, 0.75f, 0.20f, 0.95f);
        draw_range_col(start, g_vcount - start);
    }
    draw_text_block(132, y, 0.92f, selected ? 1.0f : 0.72f, selected ? 1.0f : 0.70f,
                    selected ? 1.0f : 0.68f, label);
}

static void draw_main_menu(void)
{
    draw_background(&g_tex_menu, 0.25f);

    /* faixa superior */
    {
        int start = g_vcount;
        set_blend(1);
        set_depth(0);
        ui_quad(0, 0, VIRTUAL_W, 150, 0.0f, 0.0f, 0.0f, 0.55f);
        draw_range_col(start, g_vcount - start);
    }

    draw_text_block(70, 40, 1.45f, 0.95f, 0.20f, 0.22f, "POPPY PLAYTIME");
    draw_text_block(74, 104, 0.52f, 0.85f, 0.83f, 0.80f, "PROTOTIPO PS3  -  CAPITULO 1  -  A FABRICA");

    draw_menu_item(330, "JOGAR", g_sel == 0);
    draw_menu_item(410, "OPCAO", g_sel == 1);
    draw_menu_item(490, "SAIR", g_sel == 2);

    draw_text_block(70, 640, 0.46f, 0.75f, 0.74f, 0.72f,
                    "X: CONFIRMAR    O: VOLTAR    DIRECIONAL: NAVEGAR");
    draw_text_block(70, 686, 0.40f, 0.55f, 0.55f, 0.55f,
                    "PORT NATIVO EM C / PSL1GHT  -  NAO E O JOGO ORIGINAL");
}

static void draw_chapter_menu(void)
{
    int can_continue = g_save.has_save ? 1 : 0;
    draw_background(&g_tex_chapter, 0.35f);

    draw_text_block(70, 46, 1.10f, 0.95f, 0.20f, 0.22f, "CAPITULO 1");
    draw_text_block(74, 112, 0.60f, 0.88f, 0.86f, 0.82f, "A FABRICA DE BRINQUEDOS");

    draw_menu_item(300, "COMECAR CAPITULO", g_sel == 0);
    draw_menu_item(378, can_continue ? "CONTINUAR" : "CONTINUAR (SEM SAVE)", g_sel == 1);
    draw_menu_item(456, "VOLTAR", g_sel == 2);

    draw_text_block(70, 560, 0.44f, 0.80f, 0.78f, 0.75f,
                    "ENCONTRE 3 PECAS E ALCANCE A SAIDA NO FIM DO CORREDOR.");
    draw_text_block(70, 606, 0.42f, 0.68f, 0.66f, 0.64f,
                    "ANALOGICO ESQ: MOVER   ANALOGICO DIR: OLHAR   X: PULAR");
    draw_text_block(70, 648, 0.42f, 0.68f, 0.66f, 0.64f,
                    "QUADRADO: INTERAGIR   L3: CORRER   L2/R2: MAOS DO GRABPACK");
}

static void draw_options(void)
{
    int start;
    draw_background(&g_tex_menu, 0.55f);

    start = g_vcount;
    set_blend(1);
    set_depth(0);
    ui_quad(220, 90, 840, 540, 0.03f, 0.05f, 0.06f, 0.92f);
    ui_quad(220, 90, 840, 6, 0.80f, 0.14f, 0.16f, 1.0f);
    draw_range_col(start, g_vcount - start);

    draw_text_block(260, 120, 0.90f, 0.95f, 0.30f, 0.30f, "OPCOES");

    {
        char line[128];
        snprintf(line, sizeof(line), "VOLUME: %u", (unsigned)g_save.volume);
        draw_text_block(270, 220, 0.70f, g_opt_sel == 0 ? 1.0f : 0.7f,
                        g_opt_sel == 0 ? 1.0f : 0.7f, g_opt_sel == 0 ? 1.0f : 0.7f, line);
    }
    {
        char line[128];
        snprintf(line, sizeof(line), "RESOLUCAO: %s", g_save.res ? "1920 X 1080" : "1280 X 720");
        draw_text_block(270, 292, 0.70f, g_opt_sel == 1 ? 1.0f : 0.7f,
                        g_opt_sel == 1 ? 1.0f : 0.7f, g_opt_sel == 1 ? 1.0f : 0.7f, line);
    }
    draw_text_block(270, 364, 0.62f, g_opt_sel == 2 ? 1.0f : 0.7f,
                    g_opt_sel == 2 ? 1.0f : 0.7f, g_opt_sel == 2 ? 1.0f : 0.7f, "VOLTAR");

    draw_text_block(270, 450, 0.42f, 0.70f, 0.69f, 0.67f,
                    "A RESOLUCAO E APLICADA NA PROXIMA INICIALIZACAO DO JOGO.");
    draw_text_block(270, 492, 0.42f, 0.70f, 0.69f, 0.67f,
                    "O VOLUME FICA SALVO NO ARQUIVO DE PROGRESSO.");
    draw_text_block(270, 560, 0.46f, 0.80f, 0.78f, 0.74f,
                    "X: ALTERAR    DIRECIONAL: NAVEGAR    O: VOLTAR");
}

static void draw_hud(void)
{
    char line[128];
    int start;
    float sway = sinf(g_bob) * 6.0f;

    /* maos do grabpack */
    start = g_vcount;
    set_blend(1);
    set_depth(0);
    ui_quad(-40 + sway * 0.4f, VIRTUAL_H - 210 - g_hand_anim[0] * 40,
            300, 260, 0.16f, 0.36f, 0.86f, 0.85f);
    ui_quad(VIRTUAL_W - 260 - sway * 0.4f, VIRTUAL_H - 210 - g_hand_anim[1] * 40,
            300, 260, 0.82f, 0.16f, 0.20f, 0.85f);
    draw_range_col(start, g_vcount - start);

    /* mira */
    start = g_vcount;
    ui_quad(VIRTUAL_W * 0.5f - 5, VIRTUAL_H * 0.5f - 5, 10, 10, 1.0f, 1.0f, 1.0f, 0.55f);
    draw_range_col(start, g_vcount - start);

    snprintf(line, sizeof(line), "PECAS: %d / 3", g_parts);
    draw_text_block(40, 30, 0.62f, 0.98f, 0.88f, 0.45f, line);

    if (g_msg_timer > 0.0f)
        draw_text_centered(560, 0.52f, 1.0f, 0.95f, 0.85f, g_msg);

    draw_text_block(40, 664, 0.40f, 0.72f, 0.71f, 0.68f,
                    "ESQ: MOVER  DIR: OLHAR  X: PULAR  QUADRADO: PEGAR  L2/R2: GRABPACK  START: MENU");

    if (g_flash > 0.0f) {
        start = g_vcount;
        set_blend(1);
        ui_quad(0, 0, VIRTUAL_W, VIRTUAL_H, 1, 1, 1, g_flash * 0.25f);
        draw_range_col(start, g_vcount - start);
    }
}

static void draw_complete(void)
{
    int start;
    draw_background(&g_tex_chapter, 0.55f);
    start = g_vcount;
    set_blend(1);
    set_depth(0);
    ui_quad(0, 250, VIRTUAL_W, 220, 0.0f, 0.0f, 0.0f, 0.75f);
    draw_range_col(start, g_vcount - start);

    draw_text_centered(280, 1.05f, 0.95f, 0.85f, 0.25f, "VOCE ESCAPOU!");
    draw_text_centered(390, 0.50f, 0.85f, 0.83f, 0.80f, "ALA DE MONTAGEM CONCLUIDA - CAPITULO 1");
    draw_text_centered(500, 0.46f, 0.75f, 0.74f, 0.70f, "X: VOLTAR AO MENU");
}

static void draw_loading(void)
{
    int start = g_vcount;
    set_blend(0);
    set_depth(0);
    ui_quad(0, 0, VIRTUAL_W, VIRTUAL_H, 0.0f, 0.0f, 0.0f, 1.0f);
    draw_range_col(start, g_vcount - start);
    draw_text_centered(330, 0.55f, 0.70f, 0.68f, 0.65f, "CARREGANDO...");
}

static void draw_game(void)
{
    camera_t cam = make_camera();
    int start;

    /* 3D */
    set_blend(0);
    set_depth(1);
    start = g_vcount;
    draw_world_quads(&cam);
    {
        int i;
        for (i = 0; i < 3; i++) {
            if (!g_piece_taken[i])
                draw_spinning_box(&cam, g_piece_pos[i], 0.42f, g_piece_rot + (float)i,
                                  0.95f, 0.72f, 0.18f);
        }
    }
    draw_range_col(start, g_vcount - start);
    set_depth(0);

    draw_hud();
}

/* ------------------------------------------------------------------ */
/* menus: navegacao                                                    */
/* ------------------------------------------------------------------ */
static void menu_main_input(void)
{
    if (btn_up() && g_sel > 0) g_sel--;
    if (btn_down() && g_sel < 2) g_sel++;
    if (btn_cross()) {
        if (g_sel == 0) { g_state = ST_CHAPTER; g_sel = 0; }
        else if (g_sel == 1) { g_state = ST_OPTIONS; g_opt_sel = 0; }
        else { save_write(); sysProcessExit(0); }
    }
}

static void menu_chapter_input(void)
{
    if (btn_up() && g_sel > 0) g_sel--;
    if (btn_down() && g_sel < 2) g_sel++;
    if (btn_circle()) { g_state = ST_MAIN; g_sel = 0; }
    if (btn_cross()) {
        if (g_sel == 0) start_new_chapter();
        else if (g_sel == 1) { if (g_save.has_save) continue_chapter(); else show_msg("NENHUM SAVE ENCONTRADO"); }
        else { g_state = ST_MAIN; g_sel = 0; }
    }
}

static void menu_options_input(void)
{
    if (btn_up() && g_opt_sel > 0) g_opt_sel--;
    if (btn_down() && g_opt_sel < 2) g_opt_sel++;
    if (btn_circle()) { g_state = ST_MAIN; save_write(); }
    if (g_opt_sel == 0) {
        if (btn_left() && g_save.volume > 0) g_save.volume--;
        if (btn_right() && g_save.volume < 10) g_save.volume++;
    } else if (g_opt_sel == 1) {
        if (btn_cross() || btn_left() || btn_right()) g_save.res = g_save.res ? 0 : 1;
    } else if (g_opt_sel == 2) {
        if (btn_cross()) { g_state = ST_MAIN; save_write(); }
    }
}

/* ------------------------------------------------------------------ */
/* main                                                                */
/* ------------------------------------------------------------------ */
int main(int argc, char *argv[])
{
    float dt = 1.0f / 60.0f;
    int running = 1;
    u32 frame = 0;
    int i;

    (void)argc; (void)argv;

    printf("Poppy Playtime PS3 - port nativo (C/PSL1GHT)\n");

    save_load();

    if (!init_screen(g_save.res ? 1 : 0)) {
        printf("falha ao inicializar o video/RSX\n");
        sysProcessExit(1);
    }
    printf("video: %ux%u\n", (unsigned)g_w, (unsigned)g_h);

    if (!init_shaders()) {
        printf("falha ao carregar shaders\n");
        sysProcessExit(1);
    }

    load_texture("menu_bg.raw", 1280, 720, &g_tex_menu);
    load_texture("chapter_bg.raw", 1280, 720, &g_tex_chapter);
    load_texture("font.raw", 768, 288, &g_tex_font);

    build_level();
    reset_player();
    g_msg[0] = '\0';

    ioPadInit(7);

    for (i = 0; i < 3; i++) {
        g_piece_taken[i] = (g_save.parts >> i) & 1u;
        if (g_piece_taken[i]) g_parts++;
    }

    while (running) {
        padData tmp;
        memset(&tmp, 0, sizeof(tmp));
        if (ioPadGetData(0, &tmp) == 0) {
            g_pad_prev = g_pad;
            g_pad = tmp;
        }

        /* input por estado */
        switch (g_state) {
            case ST_MAIN:    menu_main_input(); break;
            case ST_CHAPTER: menu_chapter_input(); break;
            case ST_OPTIONS: menu_options_input(); break;
            case ST_GAME:    break;
            case ST_COMPLETE:
                if (btn_cross() || btn_start()) { g_state = ST_MAIN; g_sel = 0; }
                break;
            default: break;
        }

        if (g_state == ST_LOADING) {
            g_state_timer -= dt;
            if (g_state_timer <= 0.0f) {
                g_state = ST_GAME;
                g_flash = 1.0f;
            }
        }

        if (g_state == ST_GAME) update_game(dt);

        if (g_msg_timer > 0.0f) g_msg_timer -= dt;
        if (g_flash > 0.0f) {
            g_flash -= dt * 1.8f;
            if (g_flash < 0.0f) g_flash = 0.0f;
        }

        /* render */
        wait_flip();
        set_render_target(g_buf);
        frame_clear();
        g_vcount = 0;

        switch (g_state) {
            case ST_MAIN:     draw_main_menu(); break;
            case ST_CHAPTER:  draw_chapter_menu(); break;
            case ST_OPTIONS:  draw_options(); break;
            case ST_LOADING:  draw_loading(); break;
            case ST_GAME:     draw_game(); break;
            case ST_COMPLETE: draw_complete(); break;
            default: break;
        }

        if (g_vcount > 0) rsxFlushBuffer(g_ctx);
        flip_buffer(g_buf);
        g_buf ^= 1;
        frame++;
    }

    sysProcessExit(0);
    return 0;
}
