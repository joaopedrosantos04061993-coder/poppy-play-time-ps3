# Poppy Playtime — Capítulo 1 (protótipo) — port nativo PS3

Projeto entregue em três camadas: **(1)** resposta técnica sobre a linguagem, **(2)** o jogo reescrito em **C** e compilado para **PPU/PS3**, **(3)** o pacote **`.pkg`** com a árvore `app_home` que faz o jogo aparecer no XMB.

---

## 1. "Esse jogo é em C?" — Não

O ZIP enviado é um projeto **Unity 2022.3.11f1**, portanto todo o código de jogo está em **C#** (`Assets/Scripts/*.cs`):

| Arquivo | Papel |
|---|---|
| `MenuController.cs` | menu principal, seleção de capítulo, opções, resolução |
| `FactoryPlayer.cs` | controle em primeira pessoa (DualShock 3) |
| `GrabPackController.cs` | mãos azul/vermelha, animações do GLB, raycast de coleta |
| `FactoryGameManager.cs` | objetivo (3 peças), saída, mensagens |
| `GameSaveStore.cs` | save em JSON em `persistentDataPath` |
| `BuildPrototypeGame.cs` | gerador de cenas no Editor (menu + fase) |

C# **não compila** para PlayStation 3. O PS3 executa código **PowerPC (PPU)** nativo, e o build do Unity para PS3 exigia o SDK oficial da Sony, acesso licenciado de desenvolvedor e uma versão antiga do Unity — o Unity 2022.3 sequer possui plataforma PS3 no build target. Ou seja: o ZIP, do jeito que está, **nunca** vai gerar EBOOT.BIN nem PKG.

Por isso a entrega real deste trabalho foi **reescrever o jogo em C** (a linguagem que o PS3 realmente executa) usando o SDK homebrew **PSL1GHT**, e empacotar o resultado.

---

## 2. O port em C (este projeto)

`source/main.c` (~1.100 linhas de C) reproduz o protótipo:

* **Menu** com a arte original (`MenuBackground.jpg`), botões JOGAR / OPÇÃO / SAIR, navegação por direcional e confirmação com **X**, voltar com **O**.
* **Seleção de capítulo** com a segunda arte (`ChapterBackground.jpg`), COMECAR CAPÍTULO / CONTINUAR / VOLTAR.
* **Fase 3D** em primeira pessoa: corredor de fábrica com piso, teto, paredes, pilares, esteiras, caixas, máquinas, porta final, névoa e iluminação por face.
* **3 peças** girando no cenário; colete com **Quadrado** (perto) ou com **L2/R2** (GrabPack, alcance maior e exige estar olhando para a peça).
* **Save** binário em `/dev_hdd0/game/POPP00001/USRDIR/poppy_save.dat` (peças, posição, volume, resolução).
* **Sair** volta ao XMB via `sysProcessExit`.
* Render: pipeline programável do RSX (GCM) com dois pares de shaders Cg compilados por `cgcomp` (`tex` = textura × cor, `col` = cor), projeção em perspectiva no PPU, recorte no *near plane*, *depth test* Z16, *alpha blending* para a UI.

### Controles (DualShock 3)

| Entrada | Ação |
|---|---|
| Analógico esquerdo | mover |
| Analógico direito | olhar |
| X | pular / confirmar |
| Quadrado | interagir / coletar |
| O | voltar / cancelar |
| L3 | correr |
| L2 / R2 | mão azul / mão vermelha (GrabPack) |
| START | salvar e voltar ao menu |
| Direcional | navegar nos menus |

---

## 3. Árvore `app_home` (o que aparece no XMB)

```
app_home/
├── PARAM.SFO          -> título, TITLE_ID, CATEGORY=HG, versão, resolução
├── ICON0.PNG          -> ícone 320x176 no XMB
├── PIC1.PNG           -> imagem de fundo 1920x1080
└── USRDIR/
    ├── EBOOT.BIN      -> ELF PPU (fake SELF) que o PS3 executa
    └── data/
        ├── menu_bg.raw
        ├── chapter_bg.raw
        └── font.raw
```

O XMB lê o `PARAM.SFO`; com `CATEGORY=HG` e `BOOTABLE=1` o título aparece na coluna **Jogo** e é lançado pelo `EBOOT.BIN`. É exatamente a mesma estrutura de um jogo instalado em `/dev_hdd0/game/<TITLE_ID>/`.

---

## 4. Compilar e empacotar

### Rota mais segura: GitHub Actions

O diretório `.github/workflows/build-ps3.yml` contém um workflow manual que roda em um
runner Ubuntu **x86-64**, verifica a arquitetura, instala o toolchain, aplica timeouts
em cada etapa e publica o PKG como artefato. Essa é a rota recomendada quando o PC não
tem espaço para WSL2. Envie este projeto para um repositório GitHub, abra **Actions**,
selecione **Build PS3 PKG** e clique em **Run workflow**. Ao terminar, baixe o artefato
`PoppyPlaytime-PS3-build`.

```bash
export PS3DEV=/opt/ps3dev
export PSL1GHT=$PS3DEV/psl1ght
export PATH=$PS3DEV/ppu/bin:$PSL1GHT/bin:$PATH

python3 tools/prepare_assets.py <pasta-do-projeto-unity>/Assets
bash tools/build.sh      # gera poppy_ps3.elf
bash tools/package.sh    # gera dist/app_home + dist/PoppyPlaytime_Capitulo1_PS3.pkg
```

---

## 5. Instalação no console

O PKG é **não assinado** (revisão *debug*), como todo homebrew. Ele instala e executa em:

* PS3 com **CFW** (Rebug, Ferrox, etc.) ou **HEN** (PS3HEN em 4.8x/4.9x) — via *Package Manager* / *Install Package Files*.

Em **OFW puro** não instala, porque a assinatura oficial da Sony (metadados NPDRM/EDAT) exige o SDK licenciado e as chaves privadas da Sony — indisponíveis fora da licença.

---

## 6. Limitações honestas

* Este port é um **protótipo original**, não o jogo comercial: sem os modelos do Huggy, sem capítulos 2–5, sem áudio (o PS3 não decodifica MP3/Ogg nativamente aqui; seria preciso converter para AT3/ADPCM e usar `libaudio`).
* O GLB do GrabPack (14 MB, glTFast no Unity) não é carregado: o port desenha as mãos como quads estilizados. Ler glTF no PS3 exigiria um loader próprio.
* O menu de opções grava volume/resolução no save; a resolução passa a valer na próxima inicialização.
* Nada disso foi testado em hardware real neste ambiente (não há PS3 aqui). O código foi compilado e linkado com o SDK oficial homebrew; validação final no console é necessária.
